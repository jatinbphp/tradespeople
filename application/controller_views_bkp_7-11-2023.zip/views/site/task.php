<?php include ("include/header.php") ?>
<?php include ("include/top.php") ?>
<div class="acount-page membership-page">
	<div class="container">
		<div class="row">
			<div class="col-sm-8">
				<div class="dashboard-white">
					<div class="dashboard-profile dhash-news Upload_ss">
		<h3><span>Task</span>  <button class="btn btn-primary pull-right" data-target="#tasss" data-toggle="modal">+ Create new task</button></h3>
	</div>

	<div class="dhash-news-main">
		<div class="task1">
						<input name="" type="file">
						<span class="click1">Click to create new task</span>
					</div>
	</div>
				</div>

				<div class="dashboard-white">
					<div class="tradesmen-top">
							<div class="pull-left">
								<h3><b>Completed</b></h3>
							</div>
					</div>
					<p><i>You don't have any completed tasks yet.</i></p>
				</div>
				
			</div>
			 
		</div>
	</div>
</div>
<?php include ("include/footer.php") ?>
<!-- 
<div class="modal fade popup" id="tasss" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Upload File</h4>
      </div>
      <form >
      <div class="modal-body">
        
           <div class="form-group">
           	<label>Size Bytes</label>
           	<input type="text" name="" placeholder="" class="form-control">
           </div>

           <div class="form-group">
           	<label>Owner</label>
           	<input type="text" name="" placeholder="" class="form-control">
           </div>
           <div class="form-group">
           	<label>Modified</label>
           	<input type="date" name="" placeholder="" class="form-control">
           </div>
           <div class="form-group">
           	<label>File</label>
           	<input type="file" name="" placeholder="" class="form-control">
           </div>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-warning">Save</button>
      </div>
       </form>
    </div>
  </div>
</div>
 -->