<?php include ("include/header.php") ?>
<div class="graty_bg">
	<div class="inner_list">
		<div class="container">
			<ul class="page_linkk ul_set">
				<li>
					<a href="index.php">Home</a>
				</li>
				<li class="active">
					Ask a tradesman
				</li>
			</ul>
		</div>
	</div>
</div>
<div class="Advice_c paddg_0">
	<div class="container">
		<div class="box_whitte">
		<div class="row">
			<div class="col-sm-6 col-sm-offset-3">
				<h1 class="head-home">Ask a tradesman</h1>
						<p class="text-center">
							

Before you can tackle any project, you'll want to get a good idea of how much the job will cost. Our comprehensive guides will show you the price of any home improvement work.

				</p>
			</div>
		</div>
		<div class="row">
			<div class="col-sm-4">
				<a class="boxus_1">
					<img src="img/img_1.png" class="img_r">
					<div class="contt">
						<h4>Building regulations</h4>
					</div>
				</a>
			</div>
			<div class="col-sm-4">
				<a class="boxus_1">
					<img src="img/img_2.png" class="img_r">
					<div class="contt">
						<h4>Planning permission</h4>
					</div>
				</a>
			</div>
			<div class="col-sm-4">
				<a class="boxus_1">
					<img src="img/img_3.png" class="img_r">
					<div class="contt">
						<h4>Permitted development</h4>
					</div>
				</a>
			</div>
		</div>
		<div class="row">
			<div class="col-sm-4">
				<a class="boxus_1">
					<img src="img/img_1.png" class="img_r">
					<div class="contt">
						<h4>Building regulations</h4>
					</div>
				</a>
			</div>
			<div class="col-sm-4">
				<a class="boxus_1">
					<img src="img/img_2.png" class="img_r">
					<div class="contt">
						<h4>Planning permission</h4>
					</div>
				</a>
			</div>
			<div class="col-sm-4">
				<a class="boxus_1">
					<img src="img/img_3.png" class="img_r">
					<div class="contt">
						<h4>Permitted development</h4>
					</div>
				</a>
			</div>
		</div>
		<div class="row">
			<div class="col-sm-4">
				<a class="boxus_1">
					<img src="img/img_1.png" class="img_r">
					<div class="contt">
						<h4>Building regulations</h4>
					</div>
				</a>
			</div>
			<div class="col-sm-4">
				<a class="boxus_1">
					<img src="img/img_2.png" class="img_r">
					<div class="contt">
						<h4>Planning permission</h4>
					</div>
				</a>
			</div>
			<div class="col-sm-4">
				<a class="boxus_1">
					<img src="img/img_3.png" class="img_r">
					<div class="contt">
						<h4>Permitted development</h4>
					</div>
				</a>
			</div>
		</div>
	</div>
	</div>
</div>
<!-- Slider -->



<?php include ("include/footer.php") ?>