<?php include ("include/header.php") ?>
  <div class="list-tradesmen membership-page">
    <div class="container">
      <div class="Project_nna">
        <h3>Project Name: Project for Jhon A.</h3>
    <h4>
      Dispute: Alashhab M <small>vs</small> Jhone A.(cancelled)
    </h4>
    <h4>
      Category: Work Quality issue
    </h4>
      </div>
    </div>
    
  <div class="container">
      <div class="nav_tttab">
          <ul class="ul_set">
            <li>
              <a href="#">
                <div class="stappp_img">
                  <img src="img/img_17.png" class="stappp_img1 img_r">
                  <img src="img/right-arrow.png" class="stappp_img2 img_r">
                </div>
                <h4>
                  STAGE 1
                  <span>IDENTY THE ISSUE</span>
                </h4>
              </a>
            </li>
            <li class="active">
              <a href="#">
                <div class="stappp_img">
                  <img src="img/img_17.png" class="stappp_img1 img_r">
                  <img src="img/right-arrow.png" class="stappp_img2 img_r">
                </div>
                <h4>
                  STAGE 2
                  <span>NEGOTIATIONS</span>
                </h4>
              </a>
            </li>
            <li>
              <a href="#">
                <div class="stappp_img">
                  <img src="img/img_17.png" class="stappp_img1 img_r">
                  <img src="img/right-arrow.png" class="stappp_img2 img_r">
                </div>
                <h4>
                  STAGE 3
                  <span>FINAL OFFRES / EVIDENCE</span>
                </h4>
              </a>
            </li>
            <li>
              <a href="#">
                <div class="stappp_img">
                  <img src="img/img_17.png" class="stappp_img1 img_r">
                </div>
                <h4>
                  STAGE 4
                  <span>ARBITRATION</span>
                </h4>
              </a>
            </li>
          </ul>
      </div>

      <div class="Negotiation_11">
        <div class="row">
          <div class="col-sm-8">
<div class="max_hhh1">
            <!-- loop -->
            <div class="img-name">
                <img src="img/trade1.png">
                <div class="names kentish_sss">
                <div class="kentish_sss2">
                  <div class="top_h44">
                    <h4>kentish_sss <span class="pull-right">Jul 28,2019 at 23:08 IST</span></h4>
                  </div>
                  <div class="cont_kiss">
                    <p>
                      

Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

                    </p>
                  </div>
                </div>
                </div>
              </div>
              <!-- loop -->

            <!-- loop -->
            <div class="img-name">
                <img src="img/trade1.png">
                <div class="names kentish_sss">
                <div class="kentish_sss2">
                  <div class="top_h44">
                    <h4>kentish_sss <span class="pull-right">Jul 28,2019 at 23:08 IST</span></h4>
                  </div>
                  <div class="cont_kiss">
                    <p>
                      

Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

                    </p>
                  </div>
                </div>
                </div>
              </div>
              <!-- loop -->

            <!-- loop -->
            <div class="img-name">
                <img src="img/trade1.png">
                <div class="names kentish_sss">
                <div class="kentish_sss2">
                  <div class="top_h44">
                    <h4>kentish_sss <span class="pull-right">Jul 28,2019 at 23:08 IST</span></h4>
                  </div>
                  <div class="cont_kiss">
                    <p>
                      

Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

                    </p>
                  </div>
                </div>
                </div>
              </div>
              <!-- loop -->
</div>

          </div>

          <div class="col-sm-4">
            <div class="dashboard-white edit-pro89 text-center"> 
              <div class=" dashboard-profile Locations_list11">
                  <h2>Total amount disputed <b>:$300</b></h2>
              </div>
              <div class="form-group text-right">
                <a href="#">Show milestones</a>
              </div>
              <div class="row">
                <div class="col-sm-6">
                  <p>Freelancer (You) : <b>11</b></p>
                </div>
                <div class="col-sm-6 bb_rr2">
                  <p>Employer (Alashhab M.) wants to pay: <br><b>$299</b></p>
                </div>
              </div>
              <hr>
              <div class="conta-footer">
              <p class="text-center"><b>Result:</b>Cancelled<br>
              <b class="booton-head">RESOLVED. DISPUTE CANCELLED.</b></p>
            </div>
            </div>
          </div>


        </div>
      </div>

  </div>
  </div>

<?php include ("include/footer.php") ?>