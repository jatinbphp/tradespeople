<?php include ("include/header.php") ?>
<div class="home-page">
 <div class="home-demo first-home">
	<div class="owl-carousel banner-slider">
		<div class="item">
			<div class="set-slide" style="background: url(img/banner.png);">
				 <svg width="100%" height="100%" preserveAspectRatio="none" viewBox="0 0 740 650" version="1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><polygon opacity="0.8" fill="#FFFFFF" points="0 0 740 0 700 650 0 650"></polygon></svg>
				<div class="container">
        <div class="row set-m-10">
        <div class="col-sm-10">
					<div class="row">
						<div class="col-sm-7">
							<div class="slice-text slice-text_home">
					<h1 class="nomargin">Testimonials</h1>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
					tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
					quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
					consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
					cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
					proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
				</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
	</div>

  </div>
<div class="testimonial">
	<div class="container">
		<h1 class="head-home">Testimonial</h1>
		<div class="quotes">
			<img src="img/quote.png">
		</div>		
		<div class="row">
			<div class="col-sm-8 col-sm-offset-2">
				<div class="testislider">					
					<div class="owl-carousel testimonial-slider">
						<div class="item">
							<i>
								Threr’s been a natural adoption of the platform with no training whatsoever. users immediately see the benefit to themselves, to their teams, and to the company as a whole
							</i>
							<div class="client-test">
								<img src="img/trade1.png">
								<h2>Clifford Bailey</h2>
								<p>Head of ABCXYZ</p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		
	</div>
</div>
<?php include ("include/footer.php") ?>