<?php include ("include/header.php") ?>
<div class="graty_bg">
	<div class="inner_list">
		<div class="container">
			<ul class="page_linkk ul_set">
				<li>
					<a href="index.php">Home</a>
				</li>
				<li class="active">
					Live leads
				</li>
			</ul>
		</div>
	</div>
</div>

<div class="Competitions">
	<div class="container">

		
<div class="mannjob">
	<div class="container">
		<div class="row">
			<div class="col-sm-8">
<div class="new_chhangecss2">
					<div class="top-search">
					<div class="row">
						<div class="col-sm-4">
							<div class="form-group">
								<input type="texr" name="" placeholder="Keyword" class="form-control">
							</div>
						</div>
						<div class="col-sm-4">
							<div class="form-group">
								<select class="form-control">
									<option>Trade</option>
									<option>Bathroom Fitting</option>
									<option>Bricklaying</option>
									<option>Building</option>
									<option>Carpentry &amp; Joinery</option>
									<option>Carpet &amp; Lino</option>
									<option>Central Heating</option>
									<option>Conservatories</option>
									<option>Conversions - General</option>
									<option>Damp Proofing</option>
									<option>Decking</option>
									<option>Demolition &amp; Clearing</option>
									<option>Driveways</option>
									<option>Electrical</option>
									<option>Extensions</option>
									<option>Fascias, Soffits &amp; Guttering</option>
								</select>
							</div>
						</div>
						
						<div class="col-sm-4">
							<a class="btn btn-primary btn-block">
							<i class="fa fa-search "></i> Search
						</a>
						</div>
					</div>
				</div>
		</div>

				<div class="listpress">

			<div class="boxus_2">
				
				<h4>Job of the Year 2019 - COMPETITION CLOSED</h4>
				<div class="ttime">
					<div class="pull-left">
						<span class="mmuny">
							<i class="fa fa-money"></i> Over £30,000
						</span>
					</div>
					<div class="pull-right">
						<span class="tttime1">
							<i class="fa fa-clock-o"></i> 06:12 21 August 2019
						</span>
					</div>
				</div>
				<p>
					The MyBuilder Job of the Year award celebrates the amazing jobs done by tradespeople who have gone above and beyond expectations. Congratulations to the winner!

				</p>
				<a href="#" class="btn btn-primary ">See More</a>
			</div>

			<div class="boxus_2">
				
				<h4>Job of the Year 2019 - COMPETITION CLOSED</h4>

				<div class="ttime">
					<div class="pull-left">
						<span class="mmuny">
							<i class="fa fa-money"></i> Over £30,000
						</span>
					</div>
					<div class="pull-right">
						<span class="tttime1">
							<i class="fa fa-clock-o"></i> 06:12 21 August 2019
						</span>
					</div>
				</div>
				<p>
					The MyBuilder Job of the Year award celebrates the amazing jobs done by tradespeople who have gone above and beyond expectations. Congratulations to the winner!

				</p>
				<a href="#" class="btn btn-primary ">See More</a>
			</div>
			
			<div class="boxus_2">
				
				<h4>Job of the Year 2019 - COMPETITION CLOSED</h4>
				<div class="ttime">
					<div class="pull-left">
						<span class="mmuny">
							<i class="fa fa-money"></i> Over £30,000
						</span>
					</div>
					<div class="pull-right">
						<span class="tttime1">
							<i class="fa fa-clock-o"></i> 06:12 21 August 2019
						</span>
					</div>
				</div>
				<p>
					The MyBuilder Job of the Year award celebrates the amazing jobs done by tradespeople who have gone above and beyond expectations. Congratulations to the winner!

				</p>
				<a href="#" class="btn btn-primary ">See More</a>
			</div>
			
			<div class="boxus_2">
				
				<h4>Job of the Year 2019 - COMPETITION CLOSED</h4>
				<div class="ttime">
					<div class="pull-left">
						<span class="mmuny">
							<i class="fa fa-money"></i> Over £30,000
						</span>
					</div>
					<div class="pull-right">
						<span class="tttime1">
							<i class="fa fa-clock-o"></i> 06:12 21 August 2019
						</span>
					</div>
				</div>
				<p>
					The MyBuilder Job of the Year award celebrates the amazing jobs done by tradespeople who have gone above and beyond expectations. Congratulations to the winner!

				</p>
				<a href="#" class="btn btn-primary ">See More</a>
			</div>
			
		</div>
			</div>
				<div class="col-sm-4">
    <div class="Locations_list11 fat-side-item">
        <h4><i class="fa fa-map-marker"></i> Locations around UK</h4>
        <ul class="ul_set lislocc1">
            <li><a href="#"> London</a></li>
            <li><a href="#"> Manchester</a></li>
            <li><a href="#"> Glasgow</a></li>
            <li><a href="#"> Birmingham</a></li>
            <li><a href="#"> Bristol</a></li>
            <li><a href="#"> Leeds</a></li>
            <li><a href="#"> Newcastle Upon Tyne</a></li>
            <li><a href="#"> Nottingham</a></li>
            <li><a href="#"> Liverpool</a></li>
            <li><a href="#"> Edinburgh</a></li>
            <li><a href="#"> Sheffield</a></li>
            <li><a href="#"> Northampton</a></li>
            <li><a href="#"> Reading</a></li>
            <li><a href="#"> Southampton</a></li>
            <li><a href="#"> Cardiff </a></li>
        </ul>
    </div>

    <div class="Locations_list11 fat-side-item">
        <h4><i class="fa fa-wrench"></i> Other jobs around UK</h4>
        <ul class="ul_set lislocc1">
            <li><a href="#">Architectural Services jobs</a></li>
            <li><a href="#">Bathroom Fitting jobs</a></li>
            <li><a href="#">Bricklaying jobs</a></li>
            <li><a href="#">Building jobs</a></li>
            <li><a href="#">Carpentry &amp; Joinery jobs</a></li>
            <li><a href="#">Carpet &amp; Lino jobs</a></li>
            <li><a href="#">Central Heating jobs</a></li>
            <li><a href="#">Conservatories jobs</a></li>
            <li><a href="#">Conversions - General jobs</a></li>
            <li><a href="#">Damp Proofing jobs</a></li>
            <li><a href="#">Decking jobs</a></li>
            <li><a href="#">Demolition &amp; Clearing jobs</a></li>
            <li><a href="#">Driveways jobs</a></li>
            <li><a href="#">Electrical jobs</a></li>
            <li><a href="#">Extensions jobs</a></li>
            <li><a href="#">Fascias, Soffits &amp; Guttering jobs</a></li>
            <li><a href="#">Fencing jobs</a></li>
            <li><a href="#">Fireplace Specialist jobs</a></li>
            <li><a href="#">Garden maintenance jobs</a></li>
        </ul>
    </div>
    <div class="Locations_list11 fat-side-item">
        <h4><i class="fa fa-question"></i>How lead fees work</h4>
        <p>

            When a building job is posted in your area, you’ll get the building lead if you are relevant for the job. You then have the choice to express interest, which is free. If the homeowner likes your profile and decides to shortlist you, contact details will be exchanged and you will get charged a small fee. The size of the fee depends on the estimated size of the building&ensp;job, which is determined by our in house team. You’ll know what the fee is before you express interest.

        </p>
    </div>
</div>
		</div>
	</div>
</div>
		
	</div>
</div>

<?php include ("include/footer.php") ?>