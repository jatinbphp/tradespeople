<?php include ("include/header.php") ?>
<div class="banner11">
	<div class="container">
		<div class="row">
			<div class="col-sm-6">
				<div class="box_faq1">
					<div class="connnt">
						<h3>Homeowners</h3>
					<p>
						Want to know how to post a job? Or what happens after you post one?
					</p>
					<p>
						Click the button below to visit our homeowner support centre.
					</p>
					</div>
					<div class="btoon">
						<a href="<?php echo base_url('homeowner-support'); ?>" class="btn btn-primary btn-lg">I'm a Homeowner</a>
					</div>
				</div>
			</div>
			<div class="col-sm-6">
				<div class="box_faq1 box_faq2">
					<div class="connnt">
					<h3>Trades</h3>
					<p>
						Click the button below to visit our trade support centre.
					</p>
					<p>
						Click the button below to visit our homeowner support centre.
					</p>
				</div>
					<div class="btoon">
						<a href="<?php echo base_url('tradesman-support'); ?>" class="btn btn-warning btn-lg">
						
						I'm a Trade
					</a>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php include ("include/footer.php") ?>

