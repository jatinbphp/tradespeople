<?php 
include_once('include/header.php');
?>
<style>
	.settings-frm{
		margin-top: 15px;
	}
	.edit-user-section{
		border: none;
		padding: 0;
	}
	hr{
	border-top: 1px solid #000;
	}
	.edit-user-section input{
		font-weight: 900;	 
	}
</style> 
<?php
foreach($settings as $setting){
	if($setting->type == 'marketers'){
		$min_cashout_marketer =  $setting->min_amount_cashout;
		$min_quotes_received_homeowner_m =  $setting->min_quotes_received_homeowner;
		$min_quotes_approved_tradsman_m =  $setting->min_quotes_approved_tradsman;
		$comission_ref_homeowner_m =  $setting->comission_ref_homeowner;
		$comission_ref_tradsman_m =  $setting->comission_ref_tradsman;
		$payment_method =  $setting->payment_method;
		$participating_bid =  $setting->participating_bid;
		$banner =  $setting->banner;
	}
	if($setting->type == 'homeowners'){
		$min_cashout_homwowner=  $setting->min_amount_cashout;
		$min_quotes_received_homeowner_h =  $setting->min_quotes_received_homeowner;
		$min_quotes_approved_tradsman_h =  $setting->min_quotes_approved_tradsman;
		$comission_ref_homeowner_h =  $setting->comission_ref_homeowner;
		$comission_ref_tradsman_h =  $setting->comission_ref_tradsman;
	}
	if($setting->type == 'tradsman'){
		$min_quotes_received_homeowner_t =  $setting->min_quotes_received_homeowner;
		$min_quotes_approved_tradsman_t =  $setting->min_quotes_approved_tradsman;
		$comission_ref_homeowner_t =  $setting->comission_ref_homeowner;
		$comission_ref_tradsman_t =  $setting->comission_ref_tradsman;
	}
}
?>
<div class="content-wrapper" style="min-height: 933px;">
	  <section class="content-header">
    <h1>Settings</h1>
		<ol class="breadcrumb">
			<li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li> 
			<li class="active">Settings</li>
		</ol>
  </section>
	<div class="container" style="width:100%">
		<div class="user-setting col-xs-12">
			<div class="row">
       			<?php
                    $message = '';
                    if (isset($this->session->message)) {
                      $message = $this->session->message;
                      if ($message == 'Settings Updated Successfully') { ?>
                            <div class="col-lg-12 alert alert-success mt-3 close_message" style="margin-bottom: 0px;margin-top: 10px;">
                              <button class="close" data-dismiss="alert">×</button>
                              <?php echo htmlspecialchars($message); ?>
                            </div>
                       <?php }}
                    ?>
    		</div>
			<div class="row">
				<div class="col-sm-9 box settings-frm" style="padding-left:1px;">
					<div class="user-right-side" style="margin-top:30px;">
						<form action="<?= site_url().'Admin/Admin/update_settings'; ?>" id="update_profile" method="post" enctype="multipart/form-data">  
							<div class="edit-user-section">
								<div class="msg"><?= $this->session->flashdata('msg');?></div>
								<div class="row">
									<div class="col-sm-6">
										<!-- Text input-->
										<div class="form-group">
											<label class="col-md-6 control-label" for="">Payment Method</label>  
											<div class="col-md-4" style="padding-left: 7px;padding-right: 23px;">
												<select class="form-control" name="payment_method">
													<option value="bank_transfer"<?php echo $payment_method == 'bank_transfer' ?'selected' : ''?>>Bank transfer</option>
													<option value="paypal" <?php echo $payment_method == 'paypal' ?'selected' : ''?>>Paypal</option>
												</select>
                      </div>
										</div>
									</div>
									<div class="col-sm-6">
										<!-- Text input-->
										<div class="form-group">
											<label class="col-md-6 control-label" for="">Participating bid</label>  
											<div class="col-md-4" style="padding-left: 7px;padding-right: 23px;">
												<select class="form-control" name="participating_bid">
													<option value="free" <?php echo $participating_bid == 'free' ?'selected' : ''?>>Free</option>
													<option value="paid" <?php echo $participating_bid == 'paid' ?'selected' : ''?>>Paid</option>
												</select>
                      </div>
										</div>
									</div>
									<div class="col-sm-6">
										<!-- Text input-->
										<div class="form-group">
											<label class="col-md-6 control-label" for="">Banner</label>  
											<div class="col-md-4" style="padding-left: 7px;padding-right: 23px;">
												<select class="form-control" name="banner">
													<option value="disable" <?php echo $banner == 'disable' ?'selected' : ''?>>Disable</option>
													<option value="enable" <?php echo $banner == 'enable' ?'selected' : ''?>>Enable </option>
												</select>
                      </div>
										</div>
									</div>
								</div>
								<div class="col-sm-12" style="height:31px;margin-bottom: 10px;">
									<h2>Marketer</h2>
								</div>
								<div class="form-group">
									<label class="col-md-3 control-label" for="">Minimum Amount Reached to Cashout</label>  
										<div class="col-md-2 pl-0" style="padding-left: 0px;padding-right: 33px;">
												<b><input name="min_amount_cashout_m" placeholder="" class="form-control input-md" type="text" value="<?php echo $min_cashout_marketer;?>" required=""></b>
                                        </div>
								</div>
							<div class="col-sm-5" style="padding-left:2px;">
								<div class="row">
									<p style="margin-top:0px;margin-bottom:15px;margin-left: 29px;font-size: 14px;font-weight: 600;">Referral Homeowner : </p>				
								</div>
								<div class="row">
									<div class="col-sm-12">
										<!-- Text input-->
										<div class="form-group">
											<label class="col-md-7 control-label" for="">No.of quotes a job must receives to earn</label>  
											<div class="col-md-5">
												<input  name="min_quotes_received_m" placeholder="" class="form-control input-md"  type="text" value="<?php echo $min_quotes_received_homeowner_m;?>" required >
                                        
											</div>
										</div>
									</div>
								</div>
								
								<div class="row">
									<div class="col-sm-12">
										<!-- Text input-->
										<div class="form-group">
											<label class="col-md-7 control-label" for="">Amount to earn after job post receive quotes</label>  
											<div class="col-md-5">
												<input  name="comission_ref_hm" placeholder="" class="form-control input-md"  type="text" value="<?php echo $comission_ref_homeowner_m;?>" required >
                                        
											</div>
										</div>
									</div>
								</div>
							</div>
								<div class="col-sm-5">
									<div class="row">
									<p style="margin-top:0px;margin-bottom:15px;margin-left: 29px;font-size:14px;font-weight: 600;">Referral Tradsman :</p>				
								</div>
								<div class="row">
									<div class="col-sm-12">
										<!-- Text input-->
										<div class="form-group">
											<label class="col-md-7 control-label" for="">No.of quotes a trade must provide to earn</label>  
											<div class="col-md-5">
												<input  name="min_quotes_approved_m" placeholder="" class="form-control input-md"  type="text" value="<?php echo $min_quotes_approved_tradsman_m;?>" required >
                                        
											</div>
										</div>
									</div>
								</div>
								
								<div class="row">
									<div class="col-sm-12">
										<!-- Text input-->
										<div class="form-group">
											<label class="col-md-7 control-label" for="">Amount to receive after a trade  provide quotes</label>  
											<div class="col-md-5">
												<input  name="comission_ref_tm" placeholder="" class="form-control input-md"  type="text" value="<?php echo $comission_ref_tradsman_m;?>" required >
                                        
											</div>
										</div>
									</div>
								</div>
							</div>
							</div>  
							
							<div class="edit-user-section">
								<div class="msg"><?= $this->session->flashdata('msg');?></div>
								<div class="col-sm-12" style="height:31px;margin-bottom: 10px;">
									<h2>Homeowner</h2>
								</div>
								<div class="form-group">
									<label class="col-md-3 control-label" for="">Minimum Amount Reached to Cashout</label>  
										<div class="col-md-2 pl-0" style="padding-left: 0px;padding-right: 33px;">
												<b><input name="min_amount_cashout_h" placeholder="" class="form-control input-md" type="text" value="<?php echo $min_cashout_homwowner;?>" required=""></b>
                                        </div>
								</div>
							<div class="col-sm-5" style="padding-left:2px;">
								<div class="row">
									<p style="margin-top:0px;margin-bottom:15px;margin-left:29px;font-size: 14px;font-weight:600;">Referral Homeowner :</p>				
								</div>
								
								<div class="row">
									<div class="col-sm-12">
										<!-- Text input-->
										<div class="form-group">
											<label class="col-md-7 control-label" for="">No.of quotes a job must receives to earn</label>  
											<div class="col-md-5">
												<input  name="min_quotes_received_h" placeholder="" class="form-control input-md"  type="text" value="<?php echo $min_quotes_received_homeowner_h;?>" required >
                                        
											</div>
										</div>
									</div>
								</div>
								
								<div class="row">
									<div class="col-sm-12">
										<!-- Text input-->
										<div class="form-group">
											<label class="col-md-7 control-label" for="">Amount to earn after job post receive quotes</label>  
											<div class="col-md-5">
												<input  name="comission_ref_hh" placeholder="" class="form-control input-md"  type="text" value="<?php echo $comission_ref_homeowner_h;?>" required >
                                        
											</div>
										</div>
									</div>
								</div>
							</div>
								<div class="col-sm-5">
									<div class="row">
									<p style="margin-top:0px;margin-bottom:15px;margin-left: 29px;font-size:14px;font-weight: 600;">Referral Tradsman :</p>			
								</div>
								<div class="row">
									<div class="col-sm-12">
										<!-- Text input-->
										<div class="form-group">
											<label class="col-md-7 control-label" for="">No.of quotes a trade must provide to earn</label>  
											<div class="col-md-5">
												<input  name="min_quotes_approved_h" placeholder="" class="form-control input-md"  type="text" value="<?php echo $min_quotes_approved_tradsman_h;?>" required >
                                        
											</div>
										</div>
									</div>
								</div>
								
								<div class="row">
									<div class="col-sm-12">
										<!-- Text input-->
										<div class="form-group">
											<label class="col-md-7 control-label" for="">Amount to receive after a trade  provide quotes</label>  
											<div class="col-md-5">
												<input  name="comission_ref_th1" placeholder="" class="form-control input-md"  type="text" value="<?php echo $comission_ref_tradsman_h;?>" required >
                                        
											</div>
										</div>
									</div>
								</div>
							</div>
							</div>

							<div class="edit-user-section">
								<div class="msg"><?= $this->session->flashdata('msg');?></div>
								<div class="col-sm-12" style="height:31px;margin-bottom: 10px;">
									<h2>Tradsman</h2>
								</div>
							<div class="col-sm-5" style="padding-left:2px;">
								<div class="row">
									<p style="margin-top:0px;margin-bottom:15px;margin-left:29px;font-size: 14px;font-weight: 600;">Referral Homeowner :</p>				
								</div>
								<div class="row">
									<div class="col-sm-12">
										<!-- Text input-->
										<div class="form-group">
											<label class="col-md-7 control-label" for="">No.of quotes a job must receives to earn</label>  
											<div class="col-md-5">
												<input  name="min_quotes_received_t" placeholder="" class="form-control input-md"  type="text" value="<?php echo $min_quotes_received_homeowner_t;?>" required >
                                        
											</div>
										</div>
									</div>
								</div>
								
								<div class="row">
									<div class="col-sm-12">
										<!-- Text input-->
										<div class="form-group">
											<label class="col-md-7 control-label" for="">Amount to earn after job post receive quotes</label>  
											<div class="col-md-5">
												<input  name="comission_ref_th" placeholder="" class="form-control input-md"  type="text" value="<?php echo $comission_ref_homeowner_t;?>" required >
                                        
											</div>
										</div>
									</div>
								</div>
							</div>
								<div class="col-sm-5">
									<div class="row">
									<p style="margin-top:0px;margin-bottom:15px;margin-left: 29px;font-size:14px;font-weight: 600;">Referral Tradsman :</p>				
								</div>
								<div class="row">
									<div class="col-sm-12">
										<!-- Text input-->
										<div class="form-group">
											<label class="col-md-7 control-label" for="">No.of quotes a trade must provide to earn</label>  
											<div class="col-md-5">
												<input  name="min_quotes_approved_t" placeholder="" class="form-control input-md"  type="text" value="<?php echo $min_quotes_approved_tradsman_t;?>" required >
                                        
											</div>
										</div>
									</div>
								</div>
								
								<div class="row">
									<div class="col-sm-12">
										<!-- Text input-->
										<div class="form-group">
											<label class="col-md-7 control-label" for="">Amount to receive after a trade  provide quotes</label>  
											<div class="col-md-5">
												<input  name="comission_ref_tt" placeholder="" class="form-control input-md"  type="text" value="<?php echo $comission_ref_tradsman_t;?>" required >
                                        
											</div>
										</div>
									</div>
								</div>
							</div>
							</div>
							
							<div class="edit-user-section gray-bg">
								<div class="row nomargin" style="background: #fff; padding: 10px 0;">
									<div class="col-sm-12">
										<button class="btn btn-primary" style="width: 10%;">SAVE</button>
                           
									</div>                                 
								</div>
							</div>                        
							<!-- Edit-section-->  
                        
						</form>
                        
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php include_once('include/footer.php'); ?>