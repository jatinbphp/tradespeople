<?php include ("include/header.php") ?>
 <div class="bannneroour">
 	<div class="container">
 		<h1>Pursue your passions</h1>
 	</div>
 </div>

<div class="ouer_minsssion">
	<div class="container">
		<div class="headeroo">
			<h2>Our Mission</h2>
			<div class="row">
				<div class="col-sm-10 col-sm-offset-1">
					<p>
				 Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod 					tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, 					quis nostrud exercitation ullamco
			</p>
				</div>
			</div>
		</div>
	</div>
</div>
<div class="Our_Story ">
	<div class="container">
		<div class="headeroo">
			<h2>Our Story</h2>
			
		</div>
		<div class="row">
			<div class="col-sm-10 col-sm-offset-1">
				<p>Getting things done is awesome. More accurately, being done and enjoying the outcome is the real reward of dealing with the smallest fix to the largest project. The problem is that finding someone to help you get there has remained a hassle. Wasn't technology supposed to help with things like that?</p>

				<p>
					While looking to achieve personal goals, find a language tutor for our kids, renovate our house and even clear a wasp nest from our front door, we were spending more time on legwork than on the things we love. We would rather take our kids to the park than hunt for an electrician that can come next Tuesday. We would rather take our journal to the café than search for a quality Arabic language tutor. This is why we started Bidvine. We wanted a better way to find local service providers who could do what we needed, were available when we needed them, and were interested to help. With a background in marketing and marketplaces, as a team we felt uniquely positioned to tackle this challenge and build a business that could be everyone's first and best choice for getting from to-do to done as quickly as possible.

				</p>
				<p>
					We first conceived of this idea in a shared workspace in Dubai, UAE, are building the platform in Waterloo, Canada, are creating the reality of Bidvine and going to market in London, UK - and through it all we are powered by people.
				</p>
			</div>
		</div>
	</div>
</div>
<div class="mission-about Our_Story">
<div class="container">
<div class="row">
	<div class="col-sm-10 col-sm-offset-1">
		<h3>Who are we?</h3>
		<p> Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
			tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
			quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
			consequat.</p>
			<p> Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
			tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
			quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
			consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
			cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
			proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
		<h3>How our service works</h3>
		<ol>
			<li>
				Customer submits information outlining the job they want completing.
			</li>
			<li>
				The job is checked by MyJobQuote staff to ensure authenticity.
			</li>
			<li>
				The job is sent to local tradespeople who are suitable for the job.
			</li>
			<li>
				Trades will contact the homeowner to quote the job.
			</li>
			<li>
				Customer chooses which trade to complete the job. Simple.
			</li>
		</ol>
		 <br>
		<h3>Why use our service as a homeowner?</h3>
		<ul>
			<li>
				MyJobQuote is free to use and allows you to gather up to 3 quotes with a quick form detailing your job. This saves you time searching for tradespeople and explaining to multiple trades your job. 
			</li>
			<li>
				Read reviews of trades from other homeowners. 
			</li>
			<li>
				MyJobQuote is free to use and allows you to gather up to 3 quotes with a quick form detailing your job. This saves you time searching for tradespeople and explaining to multiple trades your job. 
			</li>
			<li>
				Read reviews of trades from other homeowners. 
			</li>
		</ul>
		<div class="posrr1">
			<a href="#" class="btn btn-primary btn-lg"> Post a Job</a>
			<a href="#" class="btn btn-warning btn-lg"> How it works</a>
		 </div>
		 
		 
		 
		 <br>
		 <br>
		 
		<h3>Why join as a tradesperson?</h3>
		<ul>
			<li>
				Using our digital marketing knowledge, we directly market to customers who are seeking work completed in your area. 
			</li>
			<li>
				Unlike directories, we provide you job leads with return on Investment. Some trade directories you can pay upto £1,000 a year for your name on a list with no guarantee of work.  
			</li>
			<li>
				Flexible memberships. We will show you what membership packages are best depending on the amount of jobs available in your area. 
			</li>
			<li>
				Get a free trial. We will offer you a free trial of our service before committing.
			</li>
			<li>
			Get access to 15,000+ job leads a month.
			</li>
			<li>
			Profitable return on investment with job leads. Marketing yourself with a website, flyers or radio advertising may lead to no measurable return on investment. Buy job leads from customers who are actively looking for quotes. 
			</li>
		</ul>
		<div class="posrr1">
			<a href="#" class="btn btn-primary btn-lg"> Sign up as a trade</a>
			<a href="#" class="btn btn-warning btn-lg">How it works</a>
		 </div>
	</div>
</div>
</div>
</div>
<?php include ("include/footer.php") ?>