<?php 
include ("include/header1.php");
?>
<!-- how-it-work -->
<div class="start-sign">
	<div class="container">
		<div class="row">
			<div class="col-sm-8 col-sm-offset-2">
				<div class="white-start">				
					<div class="sing-body">
						<div class="mjq-newhome-container blank">
							<div class="about-container">
									<h2>Thank You</h2>
									<p>Your service order palced successfully</p>
									<br>
									<a class="btn btn-warning" href="<?php echo site_url(); ?>" style="margin-right:5px;">Home page</a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- upper-footer -->
<?php include ("include/footer.php") ?>
