
<script type="text/javascript" src="https://www.tradespeoplehub.co.uk/Development/js/jquery.min.js"></script>

<a class="facebook-share" target="_blank" href="https://www.facebook.com/sharer/sharer.php?u=tradespeoplehub.co.uk/share-facebook" id="share">Share on Facebook</a>

<script type="text/javascript">
	jQuery(document).ready(function(){
   	$('#share').click();
        
  	});
</script>