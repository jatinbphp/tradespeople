<?php 
include ("include/header1.php");
?>
<!-- how-it-work -->
<div class="start-sign">
	<div class="container">
		<div class="row">
			<div class="col-sm-8 col-sm-offset-2">
				<div class="white-start">
				
					<div class="sing-body">
						<div class="mjq-newhome-container blank">

							<div class="about-container">
									<h2>404: Page Not Found</h2>
									<p>Sorry but the page you were trying to load was not found.</p>
									<br>
									<a class="btn btn-warning" href="<?php echo site_url(); ?>" style="margin-right:5px;">Home page</a>
							</div>
					</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- upper-footer -->
<?php include ("include/footer.php") ?>
