<?php
	ini_set('display_errors', 1);
	include 'con1.php';
	include 'function_app_common.php'; 
	include 'function_app.php'; 
	include 'language_message.php';	
	include 'mailFunctions.php';
	// check method here
	if(!$_GET){
		$record=array('success'=>'false','msg' =>$msg_get_method); 
		jsonSendEncode($record); 
	}
 
	$user_id 	 = $_GET['user_id'];
	 
	
	//get user id chweck==========================
    $check_user_all	=	$mysqli->prepare("SELECT f_name,l_name,`id`, `email`,category,longitude,latitude,max_distance FROM `users` WHERE id=?");
	$check_user_all->bind_param("i",$user_id);
	$check_user_all->execute();
	$check_user_all->store_result();
	$check_user		=	$check_user_all->num_rows;  //0 1
	if($check_user <= 0){
		$record		=	array('success'=>'false', 'msg'=>$msg_error_user_id); 
		jsonSendEncode($record);
	} 
    $check_user_all->bind_result($f_name,$l_name,$user_id_get,$user_email,$category_ids,$longitude_user,$latitude_user,$max_distance_user);
    $check_user_all->fetch(); 
//---------------------------------------jobs-----------------------------
 $count=0;
//$getjobdetailrecent=$mysqli->prepare("SELECT job_id,project_id,title,description,userid,status,category,budget,budget2,post_code,longitude,latitude FROM tbl_jobs where  is_delete=0 and direct_hired = 0 and  category IN($category_ids) or awarded_to=$user_id  ORDER BY c_date DESC");

$getjobdetailrecent=$mysqli->prepare("SELECT job_id,project_id,title,description,userid,status,category,budget,budget2,post_code,longitude,latitude,job_end_date FROM tbl_jobs where  (status=0 or status=1 or status=2 or status=3 or status=8 or status=9) and is_delete=0 and direct_hired = 0 and DATE(job_end_date) >= DATE(NOW()) and (select count(id) from tbl_jobpost_bids where tbl_jobpost_bids.job_id = tbl_jobs.job_id and tbl_jobpost_bids.bid_by=$user_id) = 0 and category IN($category_ids) ORDER BY c_date DESC");
$getjobdetailrecent->execute();
$getjobdetailrecent->store_result();
$getjobdetailrecent_count=$getjobdetailrecent->num_rows;  //0 1
if($getjobdetailrecent_count > 0){
$getjobdetailrecent->bind_result($job_id,$project_id,$title,$description,$userid,$status,$category,$budget,$budget2,$post_code,$longitude_job,$latitude_job,$job_end_date);
while ($getjobdetailrecent->fetch()) {
	$key='cat_name';
	$tablename='category';
	$where='cat_id='.$category;
	$category_name=getSingleData($key, $tablename, $where);
	$time_current=date('Y-m-d H:i:s');
	    $dateTimestamp1 = strtotime($time_current);
        $dateTimestamp2 = strtotime($job_end_date);
	$expire_status=0;
    
     if($dateTimestamp2<$dateTimestamp1){
      $expire_status=1;
     }
	$home_ouwner=getownerDetails($userid);
	if($home_ouwner!='NA'){
		$homeowner_name=$home_ouwner['name'];
		$distance= distanceCalculation($latitude_job, $longitude_job, $latitude_user, $longitude_user, 'mi', $decimals = 2) ;

	}
	if($status==1 || $status==8){
    	$status_job='open';
	}elseif ($status==4) {
	# code...
	$status_job='In Progress';
	}else if ($status==5) {
	# code...
	$status_job='Completed';
	}
	$len = (strlen($post_code) >= 7) ? 4 : 3;
    $post_code = strtoupper(substr($post_code, 0, $len));
       

	if($distance<=$max_distance_user){
		
		if($expire_status!=1)
		{
			$count++;
	$job_detailrecent[] = array(
	'job_id' =>  $job_id,
	'project_id' =>  $project_id,
	'title'   => $title,
	'budget'   => $budget,
	'budget2'   => $budget2,
	'category_name' => $category_name,
	'description' => $description,
	'userid' => $userid,
	'status' => $status,
	'quotes' =>  $quotes,
	'status_job' =>  $status_job,
	'avg_quotes' =>  $avg_quotes,
	'distance'	=>   round($distance,2),
	'homeowner_name' =>  $homeowner_name,
	'post_code'=>$post_code,
	'expire_status'=>$expire_status,
	'job_end_date'=>$job_end_date
);
		}
}
if($count==10){

	break;
}
}
}
//-------------------------------------
	if(empty($job_detailrecent)){
		$job_detailrecent	=	'NA';
	}
	 $user_details	=	getUserDetails($user_id);
 $notification_count = getNotificationMsgCount($user_id);
	$record	=	array('success'=>'true', 'msg'=>$data_found,'user_details'=>$user_details,'job_detailrecent'=>$job_detailrecent,'notification_count'=>$notification_count); 
	jsonSendEncode($record);   
?>